# Workbench Word Backend

### Built with Flask

https://flask.palletsprojects.com/en/2.1.x/

## Run

**python3 app.py** will run the server locally.

The server should run SSL on https://127.0.0.1:5000/.

SSL is required to communicate with the Word taskpane frontend.

## Data Updates

Hit the endpoint https://127.0.0.1:5000/compute-vector to update template reference data when documents are added or removed from the 'data/templates' folder.

## Lint

Using **pylint** for linter suggestions.

https://pypi.org/project/pylint/

Using **autopep8** for auto-fixing linter suggestions.

https://pypi.org/project/autopep8/

Pep8 style cheat-sheet:

https://cheatography.com/jmds/cheat-sheets/python-pep8-style-guide/

## Notes

This backend communicates with the frontend located at https://github.com/ey-org/frontend-workbench-word.