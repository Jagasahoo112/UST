from xml.etree.cElementTree import XML
import datetime
import os
import re
import zipfile
import pandas as pd

WORD_NAMESPACE = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
PARA = WORD_NAMESPACE + 'p'
TEXT = WORD_NAMESPACE + 't'


def get_footer(path):
    document = zipfile.ZipFile(path)
    list_foot = document.namelist()
    paragraphs = []

    for i in range(1, len(list_foot)):
        xmlfile = 'word/footer' + str(i) + '.xml'
        if xmlfile in list_foot:
            xml_content = document.read('{}'.format(xmlfile))
            tree = XML(xml_content)

            for paragraph in tree.iter(PARA):
                texts = [node.text
                         for node in paragraph.iter(TEXT)
                         if node.text]
                if texts:
                    extracted_text = ''.join(texts)
                    paragraphs.append(extracted_text)

    document.close()

    footer_data = '\n'.join(paragraphs)
    temp = []
    temp_ = []
    temp_0item = []
    data_list = re.findall(r'\((.*?)\)', footer_data)

    res = True

    for i in range(len(data_list)):
        try:
            res = bool(datetime.datetime.strptime(data_list[i], '%d %B %Y'))
        except ValueError:
            res = False

        if res is False:
            try:
                res = bool(datetime.datetime.strptime(data_list[i], '%d %b %Y'))
            except ValueError:
                res = False

        if res is not False and data_list[i] not in temp:
            temp.append(data_list[i])  # date

    if len(temp) >= 1:
        temp_0item.append(temp[0])
    else:
        temp_0item.append('No footer found in template')

    for j in footer_data.split("\n"):
        if ''.join(temp) in j:
            for k in re.findall(r"(.*?)(?:\(.*?\)|$)", j):
                if len(k.strip()) > 3 and k not in temp_:
                    temp_.append(k)

    template_date = ''.join([str(elem) for elem in temp]).strip()
    template_name = ''.join([str(elem) for elem in temp_]).strip()

    return footer_data, template_name, template_date


def get_version(folderpath):
    templatedetails1 = []
    templates = os.listdir(folderpath)
    for filename in templates:
        footer_data, name, date = get_footer(folderpath + filename)
        if footer_data:
            dict1 = {
                "name": name,
                "date": date,
                "filename": filename,
                "footer_data": footer_data
            }

            templatedetails1.append(dict1)

    df = pd.DataFrame(templatedetails1)
    df.to_excel('data/template_details.xlsx')
    df.to_json(
        'db/template_details.json',
        orient='split',
        compression='infer')


def check_new_version_available(document_date, template_date):
    input_date = datetime.datetime.strptime(document_date, "%d %B %Y")
    reference_date = datetime.datetime.strptime(template_date, "%d %B %Y")

    if input_date < reference_date:
        return True
    if input_date == reference_date or input_date > reference_date:
        return False


def find_matching_template_by_name(document_name, data):
    matching_template = {}

    for i in range(0, len(data), 1):
        if document_name in data.name[i]:
            matching_template = data.loc[i].to_dict()

    return matching_template
