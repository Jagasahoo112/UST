from xml.etree.cElementTree import XML
import zipfile

WORD_NAMESPACE = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
PARA = WORD_NAMESPACE + 'p'
TEXT = WORD_NAMESPACE + 't'

def get_text(path):
    document = zipfile.ZipFile(path)
    list_foot=document.namelist()
    paragraphs = []
    
    xmlfile='word/document.xml'
    if xmlfile in list_foot:
        xml_content = document.read('{}'.format(xmlfile))
        tree = XML(xml_content)
       
        for paragraph in tree.iter(PARA):
            texts = [node.text
                 for node in paragraph.iter(TEXT)
                 if node.text]
            if texts:
                textData = ''.join(texts)
                extractedTxt = textData
                paragraphs.append(extractedTxt) 
    
    for i in range(1,len(list_foot)):
        xmlfile='word/footer'+str(i)+'.xml'
        if xmlfile in list_foot:
            xml_content = document.read('{}'.format(xmlfile))
            tree = XML(xml_content)
           
            for paragraph in tree.iter(PARA):
                texts = [node.text
                     for node in paragraph.iter(TEXT)
                     if node.text]
                if texts:
                    textData = ''.join(texts)
                    extractedTxt = "footer"+str(i)+":"+textData
                    paragraphs.append(extractedTxt)   
        
        xmlfile='word/header'+str(i)+'.xml'
        if xmlfile in list_foot:
            xml_content = document.read('{}'.format(xmlfile))
            tree = XML(xml_content)
           
            for paragraph in tree.iter(PARA):
                texts = [node.text
                     for node in paragraph.iter(TEXT)
                     if node.text]
                if texts:
                    textData = ''.join(texts)
                    extractedTxt = "header"+str(i)+":"+textData
                    paragraphs.append(extractedTxt)            
                    
                    
                    

    document.close()
    string='\n'.join(paragraphs)

    return string 
  
