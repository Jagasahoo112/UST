import re
import math
import heapq
import docx2txt
from models import doc2txt
import collections
from functools import reduce
import os


def preprocess(text):
    pattern = re.compile('[^A-Za-z0-9\-]+')
    text = text.lower()
    tokens = [token for token in text.split()]
    tokens = [re.sub(pattern, '', token).strip() for token in tokens]
    tokens = list(filter(lambda x: len(x) > 0, tokens))
    return tokens


def buildIndex(idfs):
    str2Idxs = []
    idx2Strs = []
    for i, idf in enumerate(idfs):
        keys = sorted([k for k in idf.keys()])
        str2Idx = {k: j for j, k in enumerate(keys)}
        str2Idxs.append(str2Idx)
        idx2Strs.append(keys)
    return str2Idxs, idx2Strs


def buildIdf(files):
    N = len(files)
    vocabs = []
    for i in range(3):
        vocabs.append(collections.defaultdict(set))

    for ff, file in enumerate(files):
        text = doc2txt.get_text(file)
        tokens = preprocess(text)

        n = len(tokens)

        for i in range(3):
            # 0, 1, 2
            for j in range(n - i):
                tmp = tokens[j:j + i + 1]
                tmp = ' '.join(tmp).strip()
                vocabs[i][tmp].add(ff)

    return [{k: math.log(N / len(v)) for k, v in vocab.items()} for vocab in vocabs]


def text2TfIdf(docText, idfs):
    tokens = preprocess(docText)
    ngrams = len(idfs)
    tfs = []
    for i in range(ngrams):
        tfs.append(collections.defaultdict(lambda: 0))

    n = len(tokens)
    for i in range(ngrams):
        for j in range(n - i):
            tmp = tokens[j:j + i + 1]
            tmp = ' '.join(tmp).strip()
            if tmp in idfs[i]:  # important as we only want to count whatever we saw in our templates
                tfs[i][tmp] += 1

    for i in range(ngrams):
        for k, count in tfs[i].items():
            tfs[i][k] = count * idfs[i][k]

    return tfs
    

def cosineSim(vec1, vec2):
    def getDenominator(vec):
        return math.sqrt(reduce(lambda x, y: x + y, map(lambda x: x ** 2, vec.values())))

    if len(vec1) > 0 and len(vec2) > 0:
        vec1Denominator = getDenominator(vec1)
        vec2Denominator = getDenominator(vec2)

        set1 = set(vec1.keys())
        set2 = set(vec2.keys())

        overlaps = set1.intersection(set2)  # find the intersecting keys

        if overlaps:    
            numerator = reduce(lambda x, y: x + y, map(lambda x: vec1[x] * vec2[x], overlaps))
        else:
            return 0
        return numerator / (vec1Denominator * vec2Denominator)
    else:
        return 0


def get_score(score):
    if (score > .999999999):
        return 100
    else:
        return round((score * 100), 2)


def findMatchingTemplate(templateTfIdfs, query, topk=5):
    # query is a list of tfidf
    heep = []
    for k, tfIdfs in templateTfIdfs.items():
        # print(k)
        finalScore = []
        for i, (templateVec, queryVec) in enumerate(zip(tfIdfs, query)):
            simScore = cosineSim(templateVec, queryVec)
            # print(f'\t{i}:', simScore)
            finalScore.append(simScore)

        fs = sum([m * s for m, s in zip([0.2, 0.3, 0.5], finalScore)])
        # print(f'\t\tfinal score: {fs}')

        heapq.heappush(heep, (fs, k))
        while len(heep) > topk:
            heapq.heappop(heep)

    return sorted([(nm, fs) for fs, nm in heep], key=lambda x: -x[1])
