import pandas as pd
from fast_autocomplete import AutoComplete
import json


words = {}


def prepare_data():
    data1 = pd.read_excel('data/autocomplete.xlsx', keep_default_na=False)
    #data1.head()

    data2 = pd.read_excel('data/autocomplete2.xlsx', keep_default_na=False)
    #data2.head()

    headings1_df = data1[['Sub heading', 'Boiler-plate text']]
    headings2_df = data2[['Sub Heading', 'Text']]
    headings2_df = headings2_df.rename(columns={'Sub Heading':'Sub heading', 'Text': 'Boiler-plate text'})

    headings = pd.concat([headings1_df, headings2_df])
    
    all_headings =  [s.encode('ascii', 'ignore').decode("utf-8").replace('\n',' ') for s in headings['Sub heading'].astype(str).str.decode('unicode_escape')]
    all_text = [s.encode('ascii', 'ignore').decode("utf-8") for s in headings['Boiler-plate text'].astype(str).str.decode('unicode_escape')]
    
    #all_headings = headings['Sub heading'].tolist()
    #all_text = headings['Boiler-plate text'].tolist()
    #len(all_headings), len(all_text)

    for heading, text in zip(all_headings, all_text):
        words[heading] = {'boilerplate': text}


def header_results(header_input):
    autocomplete = AutoComplete(words=words)

    res = autocomplete.search(word=header_input, max_cost=3, size=10)
    return res


def section_result(header_input):
    print(words[header_input]['boilerplate'])
    return words[header_input]




