from flask import request, Blueprint, jsonify
from models import autocomplete_model as am

autocomplete_app = Blueprint('autocomplete', __name__, template_folder='apps')


@autocomplete_app.before_app_first_request
def before_first():
    am.prepare_data()


@autocomplete_app.route('/autocomplete-headers', methods=['GET'])
def autocomplete_headers():
    args = request.args
    result = am.header_results(args['input'])
    return jsonify(result)


@autocomplete_app.route('/autocomplete-section', methods=['GET'])
def autocomplete_section():
    args = request.args
    result = am.section_result(args['input'])
    return jsonify(result)




