from turtle import done
from flask import request, Blueprint, jsonify
from elastic import header_content_index as ei
from elastic import header_content_search as es

search_header_app = Blueprint('search_headers', __name__, template_folder='apps')


@search_header_app.route('/index-data', methods=['GET'])
def index_data():
    ei.index()
    return "done"

@search_header_app.route('/search-data', methods=['GET'])
def search_data():
    args = request.args
    print(args['input'])
    result = es.search(args['input'])
    print(args)
    return jsonify(result)




