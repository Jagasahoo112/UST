from flask import request, Blueprint, jsonify
from elastic import template_index as ti
from elastic import template_search as ts

search_template_app = Blueprint('search_templates', __name__, template_folder='apps')


@search_template_app.route('/index-template-data', methods=['GET'])
def index_data():
    ti.index()
    return "done"

@search_template_app.route('/search-template-data', methods=['GET'])
def search_data():
    args = request.args
    print(args['input'])
    result = ts.search(args['input'])
    print(args)
    return jsonify(result)




