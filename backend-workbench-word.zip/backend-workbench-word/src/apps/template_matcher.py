import json
import os
import pandas as pd
from flask import request, jsonify, send_file, Blueprint, current_app
from werkzeug.utils import secure_filename
from models import doc2txt
from models import template_matcher_model as tm
from models import template_version_model as tv

ALLOWED_EXTENSIONS = set(['doc', 'docx'])
TEMPLATE_DIRECTORY = 'data/templates/'

template_matcher_app = Blueprint('template_matcher', __name__, template_folder='apps')


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def update_template_data(reference_data_path):
    global template_reference_data
    template_reference_data = pd.read_json(
        reference_data_path, orient='split', compression='infer')


@template_matcher_app.before_app_first_request
def before_first():
    global idfs
    global templateTfIdfs

    with open('db/templateTfIdfs.json', 'r', encoding='utf-8') as tfidfs_data:
        templateTfIdfs = json.load(tfidfs_data)

    update_template_data('db/template_details.json')

    with open('db/idfs.json', 'r', encoding='utf-8') as idfs_data:
        idfs = json.load(idfs_data)


@template_matcher_app.route('/compute-vector', methods=['GET'])
def compute_vector():
    global idfs
    global templateTfIdfs


    templates = [
        f'{TEMPLATE_DIRECTORY}{f}' for f in os.listdir(TEMPLATE_DIRECTORY)]

    idfs = tm.buildIdf(templates)
    templateTfIdfs = {
        template: tm.text2TfIdf(
            doc2txt.get_text(template),
            idfs) for template in templates}

    tv.get_version(TEMPLATE_DIRECTORY)

    with open('db/idfs.json', 'w', encoding='utf-8') as idfs_data:
        json.dump(idfs, idfs_data)

    with open('db/templateTfIdfs.json', 'w', encoding='utf-8') as tfidfs_data:
        json.dump(templateTfIdfs, tfidfs_data)

    update_template_data('db/template_details.json')

    return "Vector computed"


@template_matcher_app.route('/file-upload', methods=['POST'])
def file_upload():
    if 'file' not in request.files:
        resp = jsonify({'message': 'No file part in the request'})
        resp.status_code = 400
        return resp

    file = request.files['file']

    if file.filename == '':
        resp = jsonify({'message': 'No file selected for uploading'})
        resp.status_code = 400
        return resp

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filename_json = {'filename': filename}

        with open('db/wb-production.json', 'w', encoding='utf-8') as db:
            json.dump(filename_json, db)

        print(filename)

        file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
        resp = jsonify({'message': 'File successfully uploaded'})
        resp.status_code = 201
        return resp

    else:
        resp = jsonify({'message': 'Allowed file types are doc and docx'})
        resp.status_code = 400
        return resp


@template_matcher_app.route('/get-results', methods=['GET'])
def get_results():

    with open('db/wb-production.json', 'r', encoding='utf-8') as db:
        data = json.load(db)

    input_file_path = 'data/' + data['filename']

    footer_data, document_name, document_date = tv.get_footer(input_file_path)

    matching_template = {}
    template_name = ''
    template_date = ''
    filename = ''

    if document_name and document_date:

        matching_template = tv.find_matching_template_by_name(document_name, template_reference_data)

    if matching_template:

        template_name = matching_template['name']
        template_date = matching_template['date']
        filename = matching_template['filename']

        new_version_available = tv.check_new_version_available(document_date, template_date)

    if not matching_template:

        print("----Vector comparision----")
        query = tm.text2TfIdf(doc2txt.get_text(input_file_path), idfs)
        results = tm.findMatchingTemplate(templateTfIdfs, query)

        best_match = results[0]
        best_match_file_path = best_match[0]
        best_match_score = tm.get_score(best_match[1])
        filename = os.path.basename(best_match_file_path)
        new_version_available = best_match_score < 100

        print("query (" + data['filename'] + ") best matches:")
        print(f'file = {best_match_file_path}, score = {best_match_score}')

        footer_data, template_name, template_date = tv.get_footer(best_match_file_path)

    response = {}

    response['newVersionAvailable'] = new_version_available
    response['documentName'] = document_name or template_name
    response['documentVersionDate'] = document_date
    response['latestVersionDate'] = template_date
    response['latestVersionUrl'] = 'https://127.0.0.1:5000/download-file?filename={}'.format(filename)

    return jsonify(response)


@template_matcher_app.route('/download-file', methods=['GET'])
def download_file():
    path = "data/templates/" + str(request.args.get('filename'))
    return send_file(path, as_attachment=True)


@template_matcher_app.route('/', methods=['GET'])
def home():
    return "HELLO"