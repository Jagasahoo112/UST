#!/usr/bin/env python
# encoding: utf-8
ELASTIC_HOME = "https://localhost:9200"
ELASTIC_USERNAME = 'elastic'
ELASTIC_PASSWORD = 'M8A1RgILT_f=OTGjOSJp'
ELASTIC_TIMEOUT = 60
