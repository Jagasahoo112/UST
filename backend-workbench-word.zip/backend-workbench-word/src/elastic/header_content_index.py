from elasticsearch import Elasticsearch
import json
from elastic import constants as c


def index():
    es = Elasticsearch(c.ELASTIC_HOME,
                       verify_certs=False,
                       request_timeout=c.ELASTIC_TIMEOUT,
                       basic_auth=(c.ELASTIC_USERNAME, c.ELASTIC_PASSWORD))

    f = open('header_content.json',encoding='utf-8')

    doc = json.load(f)
    f.close()

    item_length = len(doc['material'])
    print(item_length)

    for i in range(item_length):
        doc_element = doc['material'][i]
        resp = es.index(index="headers-index", id=i, document=doc_element)
        print(resp['result'])
