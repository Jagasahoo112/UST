from elasticsearch import Elasticsearch
from flask import jsonify
from elastic import constants as c


def search(search_query):
    es = Elasticsearch(c.ELASTIC_HOME,
                       verify_certs=False,
                       request_timeout=c.ELASTIC_TIMEOUT,
                       basic_auth=(c.ELASTIC_USERNAME, c.ELASTIC_PASSWORD))

    query_body = {
        "query": {
            "match": {
                "name": search_query
            }
        }
    }

    resp = es.search(index="documents-index", body=query_body)
    hits = []
    for hit in resp['hits']['hits']:
        hits.append(hit["_source"])

    return hits

