from flask import Flask, Blueprint

from apps import template_matcher as template_matcher_blueprint
import pkgutil
import sys
# import Blueprint
from flask_cors import CORS


def create_app():
    app = Flask(__name__)
    CORS(app)
    app.config.from_object('config.DevelopmentConfig')

    EXTENSIONS_DIR = "apps"
    modules = pkgutil.iter_modules(path=[EXTENSIONS_DIR])
    for loader, mod_name, ispkg in modules:
        if mod_name not in sys.modules:
            loaded_mod = __import__(
                EXTENSIONS_DIR+"."+mod_name, fromlist=[mod_name])
            for obj in vars(loaded_mod).values():
                if isinstance(obj, Blueprint):
                    app.register_blueprint(obj)

    return app


if __name__ == "__main__":
    app = create_app()
    #app.run(ssl_context=('ssl/cert.pem', 'ssl/key.pem'))
    #app.run(host='0.0.0.0', port=5000, ssl_context=('ssl/cert.pem', 'ssl/key.pem'))
    app.run()
