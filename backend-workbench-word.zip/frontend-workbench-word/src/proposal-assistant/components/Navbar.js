import React, {useState} from 'react';

const Navbar = (props) => {

    return (
            <button
              id="toggle"
              className="menu-icon-btn py-2"
              data-menu-icon-btn
              onClick={() => props.onClick(!props.showSideBar)}
            > Toggle Sidebar
            </button>
    )
    }
    
export default Navbar;