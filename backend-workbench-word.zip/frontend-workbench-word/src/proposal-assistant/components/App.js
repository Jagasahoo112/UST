import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import Progress from "./Progress";
import Header from "./Header";
import Dashboard from "./Dashboard";
import { Spinner, SpinnerSize } from '@fluentui/react/lib/Spinner';
import { MessageBar } from '@fluentui/react';
import autocompleteApi from "../apis/autocomplete";
import officeJsApi from "../apis/officeJs";
import getMessage from "../helpers/getMessage";
import LongTextOption from "./LongTextOption";
import ShortTextOption from "./ShortTextOption";
import ResultsMessage from "./ResultsMessage";
import Collapsible from "./expand"


/* global Word, Office */

const MINIMUM_INPUT_LENGTH = 3;

const App = (props) => {
  const [loading, setLoading] = useState(false)
  const [headerOptions, setHeaderOptions] = useState([])
  const [boilerplateOptions, setBoilerplateOptions] = useState([])
  const [inputText, setInputText] = useState('')
  const [autocompletedText, setAutocompletedText] = useState('')

  const { isOfficeInitialized, title } = props;

  useEffect(() => {
    if (isOfficeInitialized) {
      Office.context.document.addHandlerAsync(Office.EventType.DocumentSelectionChanged, handleDocumentChanged)
    }
    
  }, [isOfficeInitialized])

  useEffect(() => {
    if (autocompletedText) {
      fetchBoilerplate(autocompletedText)
    }
  }, [autocompletedText])

  useEffect(() => {
    if (inputText && autocompletedText !== inputText) {
      setHeaderOptions([])
      setBoilerplateOptions([])
      setAutocompletedText('')
    }
  }, [autocompletedText, inputText])

  async function handleDocumentChanged(event) {
    try {
      const text = await officeJsApi.getTextBeforeCursorLocation()
      const trimmedText = text.trim();
      setInputText(trimmedText)

      if (trimmedText.length > MINIMUM_INPUT_LENGTH) {
        setLoading(true)
        setHeaderOptions([])

        const options = await autocompleteApi.getHeaderSuggestions(trimmedText)
        console.log("options",options)
        const formattedOptions = options.map(option => {
          return {
            text: option,
            onClick: () => {
              officeJsApi.replaceText({ existingText: text, replacementText: option, fontSize: 18 })
              setAutocompletedText(option)
              setHeaderOptions([])
            }
          }
        })
        console.log("aaaaaaaaaaaaaaaaaaaa",formattedOptions)
        setHeaderOptions(formattedOptions)
      }

    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  async function fetchBoilerplate(autocompletedText) {
    try {
      // setLoading(true)
     console.log("*********",autocompletedText)
     //console.log("*********",JSON.parse(autocompletedText))
      // const options = autocompletedText['Boiler-plate text']
      // const opt= autocompletedText['Sub heading']
      // //console.log("options",options)
      // //const formattedOptions = options.map(option => {
      //   return {
      //     text: opt,
      //     onClick: () => {
      //       officeJsApi.insertText({ text: "\n\n" + options, fontSize: 14 })
      //       setAutocompletedText('')
      //       setBoilerplateOptions([])
      //     }
      //   }
      // // })
      // setLoading(true)
      // const options = await autocompleteApi.getBoilerplate(autocompletedText)
      // console.log("options",options)
      // const opt2 = autocompletedText['Boiler-plate text']
      // const opt= autocompletedText['Sub heading']
      // const obj = Object.entries(autocompletedText)
      // const formattedOptions = obj.forEach(([key, value]) => {
      //   console.log(key, value)
      //   return {
      //     text: key,
      //     onClick: () => {
      //       officeJsApi.insertText({ text: "\n\n" + val, fontSize: 14 })
      //       setAutocompletedText('')
      //       setBoilerplateOptions([])
      //     }
      //   }
      // })  
      // const formattedOptions = options.map(option => {
      //   return {
      //     text: option,
      //     onClick: () => {
      //       officeJsApi.insertText({ text: "\n\n" + opt2, fontSize: 14 })
      //       setAutocompletedText('')
      //       setBoilerplateOptions([])
      //     }
      //   }
      // })

      // setBoilerplateOptions(formattedOptions)

      setLoading(true)
      const options = await autocompleteApi.getBoilerplate(autocompletedText)
      //console.log("optionssssss",options)
      const obj = Object.entries(autocompletedText)
      // const formattedOptions = options.map(option => {
      //   console.log(option)
      //   return {
      //     text: option,
      //     onClick: () => {
      //       officeJsApi.insertText({ text: "\n\n" + option, fontSize: 14 })
      //       setAutocompletedText('')
      //       setBoilerplateOptions([])
      //     }
      //   }
      // })     
      console.log("obj",obj)
      const arr=[];
      obj.forEach(([key, value]) => { arr.push(value)})
       console.log("arr",arr)
       const ddt = []
       ddt.push(arr[0])
       console.log(ddt)
        const formattedOptions = ddt.map(option => {          
          //return {
            //text: option,
            //onClick: () => {
              officeJsApi.insertText({ text: "\n\n" + option, fontSize: 14 })
              //officeJsApi.replaceText({ existingText: text, replacementText: option, fontSize: 14 })
              //setAutocompletedText('')
              //setBoilerplateOptions([])
            //}
          //}
        })  
      console.log("formattedOptions",formattedOptions)
      //setBoilerplateOptions(formattedOptions)

    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  if (!isOfficeInitialized) {
    return (
      <Progress
        title={title}
        logo={require("./../../../assets/ey-logo-80.png")}
        message="Please sideload your addin to see app body."
      />
    );
  }

  const { messageText, messageIcon, messageSpinner } = getMessage({ 
    suggestionsExist: headerOptions.length > 0 || boilerplateOptions.length > 0, 
    textLength: inputText.length,
    minimumTextLength: MINIMUM_INPUT_LENGTH 
  })

  return (
    <div className="proposal-assistant">
      {/* <Dashboard/> */}
      <Header title="Auto Suggestion" />
      <div>
        <input type="text"/>
        <input type="text"/>
      </div>
      <div className="message-bar-container">
        <MessageBar className="suggestions-enabled-message">
            Auto Suggestion is enabled.
        </MessageBar>
      </div>

      <div className="suggestions">

        { loading && <Spinner size={SpinnerSize.large} /> }

        { !loading &&
          <ResultsMessage {...{
            text: messageText,
            icon: messageIcon,
            spinner: messageSpinner
          }}/>
        }


        {/* { boilerplateOptions.length === 0 && 
           headerOptions.map((option, i) => {
            return (
              <ShortTextOption key={`short-text-option-${i}`} {...{
                text: option.text,
                onClick: option.onClick
              }}/>
            )
          })
        } */}
       { console.log("headerOptionsheaderOptions",headerOptions)}
        { boilerplateOptions.length === 0 && 
          headerOptions.map((option, i) => {
            return (
              <Collapsible key={`short-text-option-${i}`} {...{
                text: option.text['Sub heading'],
                longtext:  option.text['Boiler-plate text'],
                onClick: option.onClick
              }}/>
            )
          })
        }

        {
          boilerplateOptions.map((option, i) => {
            return (
              <Collapsible key={`long-text-option-${i}`} {...{
                text: option.text['Sub heading'],
                longtext:  option.text['Boiler-plate text'],
                onClick: option.onClick
              }}/>
            )
          })
        }
      </div>
    </div>
  );
};

App.propTypes = {
  title: PropTypes.string,
  isOfficeInitialized: PropTypes.bool,
};

export default App;
