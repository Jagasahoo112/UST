import React, { useEffect, useRef, useState } from "react";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
//import "./Dashboard.css";

const Dashboard = () => {
  // i don't know what is using for..
  const sidebarRef = useRef(null); // used to get sidebar width
  const [isMobile, setMobile] = useState(document.body.clientWidth <= 498);
  // use 'init' | 'open' | 'close', that you don't need remember if suer clicked
  const [sidebarStatus, setSidebarStatus] = useState("init");

  useEffect(() => {
    // add listener only once, or many listeners would be created every render
    const mq = window.matchMedia("(max-width: 498px)");
    mq.addListener((res) => {
      setMobile(res.matches);
    });
    return () => mq.removeListener(toggleSidebar);
  }, []);

  // react use status change fire effects, fire function manually is tired
  // here calculate should show sidebar
  const showSidebar =
    sidebarStatus === "open" || (!isMobile && sidebarStatus === "init");

  const toggleSidebar = (open) => {
    setSidebarStatus(open ? "open" : "close");
  };


  return (
    <>
      <span ref={sidebarRef}>
        {showSidebar && <Sidebar onClick={toggleSidebar} />}
      </span>
      <div className="flex-fill content-wrapper">
        <Navbar showSideBar={showSidebar} onClick={toggleSidebar} />
      </div>
    </>
  );
};

export default Dashboard;