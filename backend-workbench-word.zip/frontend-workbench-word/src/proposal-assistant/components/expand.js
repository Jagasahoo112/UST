import React, { useState } from "react";
import useCollapse from "react-collapsed";
import officeJsApi from "../apis/officeJs";
import classNames from "classnames"
import { Link } from "@fluentui/react";
import nl2br from "../helpers/newLinetoBreak";
import PropTypes from "prop-types";

function Collapsible({ text, longtext, onClick }) {
  const [showAllText, setShowAllText] = useState(false);
  
  function toggleViewMore(event) {
    event.stopPropagation();
    setShowAllText(!showAllText);
  }
  const { getCollapseProps, getToggleProps, isExpanded } = useCollapse();

  return (
    <div className="collapsible">
      <div className="short-text-option" >
        <div className="auto-header" onClick={(event) => clickHeader(event, text)}>
          {text != undefined ? text : null}
        </div>
        <button className="short-text-expand" {...getToggleProps()} >
          {isExpanded ? "Close" : "Expand"}
        </button> 
      </div> 
      <div {...getCollapseProps()}>
        <div className="long-text-option" role="button">
          <div className="long-text-option-content">
            <div
              className={classNames("long-text-option-text", { collapsed: !showAllText })}
              onClick={(event) => clickdetailsHeader(event, longtext)}
            >
              {nl2br(longtext)}
            </div>
            <Link className="view-more-button">{showAllText ? "View Less" : "View More"}</Link>
          </div>
        </div>
      </div> 
    </div>
  );
}

function clickHeader(event,option)
{
    console.log("sdfsdfsdfsdfsdfsdfsdfsx");
    officeJsApi.insertText({ text: "\n\n" + option, fontSize: 14 })
  //officeJsApi.replaceText({ existingText: option, replacementText: option, fontSize: 14 });
}
 
function clickdetailsHeader(event,option)
{
    console.log("cccccccccccccccccc");
  officeJsApi.insertText({ text: "\n\n" + option, fontSize: 14 });
  //officeJsApi.replaceText({ existingText: option, replacementText: option, fontSize: 14 });
}
Collapsible.propTypes = {
  text: PropTypes.string,
  longtext: PropTypes.string,
  onClick: PropTypes.func,
}

export default Collapsible;
