import * as React from "react";
import PropTypes from "prop-types";
import Progress from "./Progress";
import Header from "./Header";

/* global Word, Office */

const App = (props) => {
  const { isOfficeInitialized, title } = props;

  if (!isOfficeInitialized) {
    return (
      <Progress
        title={title}
        logo={require("./../../../assets/ey-logo-80.png")}
        message="Please sideload your addin to see app body."
      />
    );
  }

  return (
    <div className="template-search">
      <Header title="Template Search" />
    </div>
  );
};

App.propTypes = {
  title: PropTypes.string,
  isOfficeInitialized: PropTypes.bool,
};

export default App;
